﻿using System;
using System.IO;

namespace w1d2
{
    public class DirThing
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            var start = DateTime.Now;
            var di = Directory.GetFiles(".");
            foreach (var d in di)
            {
                var f = new FileInfo(d);
                f.Refresh();
                var fileTime = f.LastWriteTime.ToString("MMM dd HH:mm");
                Console.WriteLine("{0, 10} {1} {2}", f.Length, fileTime, f);
            }

            var end = DateTime.Now;
            Console.WriteLine(end-start);
            Console.ReadKey();

        }
    }    
}
